package cn.com.ttg.api.bean;

import java.io.Serializable;
import java.util.Date;

/**
 * 已绑定的会员卡的信息
 * 带有部分用户信息 和 会员卡数据
 * @author leon
 *
 */
public class VipUserCard implements Serializable {
	private static final long serialVersionUID = 8890371694833446425L;
	private Integer uvcid;
	private Integer vipcardnum;
	private Integer vcamount;
	private Integer state;
	private String cou_bankno;
	private String union_orderid;
	private String extra;
	private String extra2;
	private String curid;
	private Date lastusetime;
	private String notify_url;
	private String addtime;
	private Integer shopid;
	private Integer svcid;
	private String shopname;
	private String vclogo;
	private Integer levelsnum;
	private Date stime;
	private Date etime;
	private Date updatetime;
	private Integer r;

	public Integer getUvcid() {
		return uvcid;
	}

	public void setUvcid(Integer uvcid) {
		this.uvcid = uvcid;
	}

	public Integer getVipcardnum() {
		return vipcardnum;
	}

	public void setVipcardnum(Integer vipcardnum) {
		this.vipcardnum = vipcardnum;
	}

	public Integer getVcamount() {
		return vcamount;
	}

	public void setVcamount(Integer vcamount) {
		this.vcamount = vcamount;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public String getCou_bankno() {
		return cou_bankno;
	}

	public void setCou_bankno(String cou_bankno) {
		this.cou_bankno = cou_bankno;
	}

	public String getUnion_orderid() {
		return union_orderid;
	}

	public void setUnion_orderid(String union_orderid) {
		this.union_orderid = union_orderid;
	}

	public String getExtra() {
		return extra;
	}

	public void setExtra(String extra) {
		this.extra = extra;
	}

	public String getExtra2() {
		return extra2;
	}

	public void setExtra2(String extra2) {
		this.extra2 = extra2;
	}

	public String getCurid() {
		return curid;
	}

	public void setCurid(String curid) {
		this.curid = curid;
	}

	public Date getLastusetime() {
		return lastusetime;
	}

	public void setLastusetime(Date lastusetime) {
		this.lastusetime = lastusetime;
	}

	public String getNotify_url() {
		return notify_url;
	}

	public void setNotify_url(String notify_url) {
		this.notify_url = notify_url;
	}

	public String getAddtime() {
		return addtime;
	}

	public void setAddtime(String addtime) {
		this.addtime = addtime;
	}

	public Integer getShopid() {
		return shopid;
	}

	public void setShopid(Integer shopid) {
		this.shopid = shopid;
	}

	public Integer getSvcid() {
		return svcid;
	}

	public void setSvcid(Integer svcid) {
		this.svcid = svcid;
	}

	public String getShopname() {
		return shopname;
	}

	public void setShopname(String shopname) {
		this.shopname = shopname;
	}

	public String getVclogo() {
		return vclogo;
	}

	public void setVclogo(String vclogo) {
		this.vclogo = vclogo;
	}

	public Integer getLevelsnum() {
		return levelsnum;
	}

	public void setLevelsnum(Integer levelsnum) {
		this.levelsnum = levelsnum;
	}

	public Date getStime() {
		return stime;
	}

	public void setStime(Date stime) {
		this.stime = stime;
	}

	public Date getEtime() {
		return etime;
	}

	public void setEtime(Date etime) {
		this.etime = etime;
	}

	public Date getUpdatetime() {
		return updatetime;
	}

	public void setUpdatetime(Date updatetime) {
		this.updatetime = updatetime;
	}

	public Integer getR() {
		return r;
	}

	public void setR(Integer r) {
		this.r = r;
	}

}
