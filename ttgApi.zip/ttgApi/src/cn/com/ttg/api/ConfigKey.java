package cn.com.ttg.api;

public class ConfigKey {
	
	public static String appkey = "appkey";
	public static String AppSecret = "AppSecret";
	public static String urlpath = "urlpath";
	public static String apiserver = "apiserver";
	public static String httpport = "httpport";
	public static String useragent = "useragent";
	public static String http = "http";
	public static String debug = "debug";

}
