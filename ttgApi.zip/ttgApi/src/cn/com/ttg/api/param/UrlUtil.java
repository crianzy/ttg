package cn.com.ttg.api.param;

/**
 *  url 工具防止硬编码
 * @author leon
 *
 */
public class UrlUtil {

	public static final String url="http://openapi.ttg.cn/coupon/v1";
}
